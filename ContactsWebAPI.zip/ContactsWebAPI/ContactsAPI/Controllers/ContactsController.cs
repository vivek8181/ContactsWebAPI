﻿using Contacts.Infrastructure;
using Contacts.Infrastructure.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ContactsAPI.Controllers
{
    public class ContactsController : ApiController
    {
        private readonly IContactsRepository repository; 

        public ContactsController(IContactsRepository repository)
        {
            this.repository = repository;
        }

        [HttpGet]
        [Route("api/{Contacts}")]
        [ActionName("GetContacts")]
        public IHttpActionResult Get()  //Lists all Active Contacts
        {
               return   Ok(repository.GetContacts());
        }

        [HttpGet]
        [Route("api/{Contacts}/{id}")]
        [ActionName("GetContactByID")]
        public IHttpActionResult Get(int id)
        {
            var c = repository.GetContactByID(id);
            if(c==null)
            {
                return NotFound();
            }
            else
            {
                return Ok(c);
            }
          
        }

        [HttpPost]
        [ActionName("AddContact")]
        public IHttpActionResult Post([FromBody]Contact contact)
        {
          if(  repository.Add(contact))
            {
                return Created<Contact>("", contact);
            }
            else
            {
                return BadRequest();
            }

        }

       
        [HttpPut, Route("UpdateContact/{id}")]
        public IHttpActionResult Put(int id, [FromBody]Contact contact)
        {
         if(   repository.Update(contact))
            {
                return Ok();

            }
         else
            {
                return NotFound();
            }
        }

        [HttpDelete, Route("DeleteContact/{id}")]
        public IHttpActionResult Delete([FromUri]int id)
        {
           if( repository.Remove(id))
            {
                return Ok();
            }
            else
            {
                return NotFound();
            }
        }
    }
}

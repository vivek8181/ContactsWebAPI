﻿using Contacts.Infrastructure.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contacts.Infrastructure
{
    public class ContactsRepository : IContactsRepository
    {

        public bool Add(Contact c)
        {
            bool result = false;
            try
            {
                using (var context = new ContactsDBEntities2())
                {
                    context.Contacts.Add(c);
                    context.SaveChanges();
                }
                result = true;
            }
            catch (Exception ex)
            {
                //[todo] add logs for exception
                result = false;
            }

            return result;

        }

        public IEnumerable<Contact> GetContacts()
        {
            try
            {
                using (var context = new ContactsDBEntities2())
                {
                    return context.Contacts.Where(c => c.Status == 1); //[todo] try to make it Enum
                }
            }
            catch (Exception)
            {
                //[todo] add logs for exception
                //throw;
            }
            return null;
        }

        public Contact GetContactByID(int  id)
        {
            try
            {
                using (var context = new ContactsDBEntities2())
                {
                    return context.Contacts.FirstOrDefault(c=>c.ID==id);
                }
            }
            catch (Exception)
            {
                //[todo] add logs for exception
                //throw;

            }
            return null;
        }

        public bool Remove(int id)
        {
            bool result = false;
            try
            {
                using (var context = new ContactsDBEntities2())
                {
                   var contact= context.Contacts.FirstOrDefault(x => x.ID == id);
                    contact.Status = 2;//todo try to use enums
                    context.SaveChanges();
                }
                result = true;
            }
            catch (Exception ex)
            {
                //[todo] add logs for exception
                result = false;
            }

            return result;
        }

        public bool Update(Contact c)
        {
            bool result = false;
            try
            {
                using (var context = new ContactsDBEntities2())
                {
                    var contact = context.Contacts.FirstOrDefault(x => x.ID == c.ID);

                    if (contact != null)
                    {
                        // Remove old item and Add new item, this will help to minimize any misses in properties update.
                        //Also, from maintanace point of view if new property is added to contacts, it would not require changes in this class.
                        context.Contacts.Remove(contact);
                        context.Contacts.Add(c);
                        context.SaveChanges();
                    }
                    else
                    {
                        throw new Exception("Contact to update not found");
                    }
                  
                }
                result = true;
            }
            catch (Exception ex)
            {
                //[todo] add logs for exception
                result = false;
            }

            return result;
        }
    }
}

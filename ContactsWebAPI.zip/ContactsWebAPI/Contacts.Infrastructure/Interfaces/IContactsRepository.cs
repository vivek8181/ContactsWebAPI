﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Contacts.Infrastructure.Interfaces
{
    public interface IContactsRepository
    {
        IEnumerable<Contact> GetContacts();
     Contact   GetContactByID(int id);
        bool Add(Contact c);
        bool Remove(int id);
        bool Update(Contact c);
    }
}
